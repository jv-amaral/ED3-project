//Alunos:
//João Vitor Amaral Santos - 16812120
//Victor Hugo Albertino e Silva - 16903448

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>

#include "funcoes_base2.h"
#include "funcionalidades2.h"

int main() {
    int funcionalidade;
    scanf("%d", &funcionalidade);

    //switch utilizado para selecionar qual funcionalidade deve ser executada
    switch (funcionalidade)
    {
        case 1: 
            leitura_e_gravacao();
            break;
        case 2: 
            recuperacao_dados();
            break;
        case 3:
            busca_condicional();
            break;
        case 4:
            busca_RRN();
            break;
        case 5:
            remocao_logica();
            break;
        case 6: 
            insercao();     
            break;
        case 7:
            atualizacao_registros();
            break;
        case 8:

            break;
        case 9:
            create_index();
            break;
        case 10:
                break;
        case 11:
            busca();
            break;
    }
    
    return 0;
}