// arquivo das funcoes

#include <ctype.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "funcionalidades.h"
#include "funcoes_base.h"

// Funcionalidade 1
void leitura_e_gravacao() // Função para ler o arquivo CSV e gravar os registros no arquivo binário
{

    // declara as variáveis para armazenar os nomes dos arquivos CSV e binário
    char arquivo_csv[50];
    char arquivo_binario[50];

    // le o nome dos arquivos CSV e binário
    scanf("%s", arquivo_csv);
    scanf("%s", arquivo_binario);

    RegCabecalho cabecalho;
    Registro Reg;

    // abre os arquivos para leitura e escrita, respectivamente
    FILE *csv = fopen(arquivo_csv, "r");

    // verifica se os arquivos nao sao nulos
    if (csv == NULL)
    {
        printf("Falha no processamento do arquivo.\n");
        return;
    }

    FILE *binario = fopen(arquivo_binario, "wb");

    if (binario == NULL)
    {
        printf("Falha no processamento do arquivo.\n");
        fclose(csv);
        return;
    }

    // atribui valores iniciais aos campos do cabeçalho e escreve o registro de cabeçalho no arquivo binário
    cabecalho.status = '0';
    cabecalho.topo_pilha = -1;
    cabecalho.proxRRN = 0;
    cabecalho.nroRegRem = 0;
    cabecalho.nroPares = 0;

    escreve_cabecalho(binario, &cabecalho);

    // atribuicao inicial de valores aos campos do registro
    Reg.removido = '0';
    Reg.encadeamento = -1;

    char linha_csv[100];

    fgets(linha_csv, sizeof(linha_csv), csv); // le a primeira linha do arquivo csv e descarta, porque é so os titulos dos campos

    // inicia o loop, fazendo a verificação de nulo
    while ((fgets(linha_csv, sizeof(linha_csv), csv)) != NULL)
    {

        // atribui os valores do csv para os campos do registro
        // strtok é usada para procurar a virgula, e atoi converte o texto para o numero inteiro correspondente
        char *primeira_virgula = strchr(linha_csv, ',');
        char *segunda_virgula = strchr(primeira_virgula + 1, ',');
        char *terceira_virgula = strchr(segunda_virgula + 1, ',');

        Reg.idPoPs = atoi(strtok(linha_csv, ","));
        Reg.idPoPsConectado = atoi(strtok(NULL, ","));

        char *velocidade_ptr = segunda_virgula + 1;
        *terceira_virgula = '\0';

        // verifica se o campo velocidade é nulo e atribui -1 se for o caso, caso contrário, o valor lido do csv é copiado para a variável Reg.velocidade
        if (velocidade_ptr[0] == '\0' || velocidade_ptr[0] == ' ')
        {
            Reg.velocidade = -1; // atribui -1 se o campo for nulo
        }
        else
        {
            Reg.velocidade = atoi(velocidade_ptr);
        }

        char *unidade_medida_ptr = terceira_virgula + 1;
        unidade_medida_ptr[strcspn(unidade_medida_ptr, "\n\r")] = '\0';

        // verifica se o campo de unidade de medida é nulo e atribui '$' para ser usado como lixo
        if (unidade_medida_ptr[0] == '\0' || unidade_medida_ptr[0] == ' ')
        {
            Reg.unidade_medida = '$';
        }
        else
        {
            Reg.unidade_medida = unidade_medida_ptr[0];
        }

        // escreve os campos do registro no arquivo binário
        escreve_registro(binario, &Reg);

        // atualiza os valores do cabeçalho do proxRRN e do numero de pares
        cabecalho.proxRRN++;
        cabecalho.nroPares++;
    }

    // escreve o cabecalho atualizado
    fseek(binario, 0, SEEK_SET);
    escreve_cabecalho(binario, &cabecalho);

    // atualiza o status para 1, ou seja, consistente
    cabecalho.status = '1';

    // escreve o status por ultimo, para garantir a integridade do arquivo
    fseek(binario, 0, SEEK_SET);
    fwrite(&cabecalho.status, sizeof(char), 1, binario);

    fclose(csv);
    fclose(binario);

    BinarioNaTela(arquivo_binario);
}

// aqui se encerra a funcionalidade 1 / Create Table
//_______________________________

// Funcionalidade 2
void recuperacao_dados() // funcao para recuperar os dados do arquivo binario e imprimir na tela
{
    // declara a variavel para armazenar o nome do arquivo e o le
    char arquivo_binario[50];
    scanf("%s", arquivo_binario);

    Registro Reg;
    FILE *binario = verificar_arquivo(arquivo_binario, "rb");
    if (binario == NULL) // Se encontrar algum erro, ele retorna
    {
        return;
    }
    // pula para o byteoffset 17 do arquivo (pois e onde começam os registros) e os le
    fseek(binario, 17, SEEK_SET);

    int registros_lidos = 0; // contador para verificar se algum registro foi lido

    while (Leitura_Registro(binario, &Reg) == 1) // se o registro existir ele será lido
    {
        if (Reg.removido == '1') // se o registro estiver removido, ele é ignorado
        {
            continue;
        }
        registros_lidos++; // incrementa se o registro for lido
                           // atribuicao dos valores nulos na hora de printar na tela

        print_registro(&Reg); // chama a funcao responsavel por printar
    }
    if (registros_lidos == 0) // printa na tela caso nenhum registro tenha sido lido
    {
        printf("Registro inexistente.\n");
    }
    fclose(binario);
}

// aqui se encerra a funcionalidade 2
//_______________________________

//______________________
// Funcionalidade 3

void busca_condicional()
{
    // crio as variaveis do nome do arquivo e do numero de repeticoes da busca
    char arquivo_binario[50];
    int repeticoes;

    // ler o nome do arquivo e o numero de repeticoes a serem levadas em conta
    scanf("%s %d", arquivo_binario, &repeticoes);

    FILE *binario = verificar_arquivo(arquivo_binario, "rb");

    if (binario == NULL)
    {
        return;
    }

    // inicia o laco externo de n buscas
    for (int busca_atual = 0; busca_atual < repeticoes; busca_atual++)
    {
        // vai ver quantos criterios serao levados em conta na busca
        int qtd_criterios;
        scanf("%d", &qtd_criterios);

        Criterios C = ler_criterios(qtd_criterios);

        // pula para o byteoffset 17 do arquivo (pois é onde começam os registros)
        fseek(binario, 17, SEEK_SET);
        Registro Reg;

        int registros_encontrados = 0;

        // comeca a percorrer todos os registros, com a condicao de que quando nao encontrar
        // registro de removido, 0 ou 1, o arquivo terminou

        while (Leitura_Registro(binario, &Reg))
        {
            // enquanto e possivel fazer a leitura do registo
            //  e feita a verificao do encontro dos criteiros
            if (Reg.removido == '1')
                continue;

            if (verificar_encontro(&C, &Reg))
            {
                registros_encontrados++; // incrementa o contador
                print_registro(&Reg);    // chama a funcao responsavel por printar
            }
        }

        // se nao e encontrado nenhum registro que contem o valor do
        // campo ou o campo pertence a um registro que esteja removido
        if (registros_encontrados == 0)
        {
            printf("Registro inexistente.\n");
        }
        printf("\n");
    }

    fclose(binario);
}
// aqui se encerra a funcionalidade 3
//_______________________________

// Funcionalidade 4
void busca_RRN()
{
    int RRN;
    char arquivo_binario[50];

    scanf("%s", arquivo_binario);

    FILE *binario = verificar_arquivo(arquivo_binario, "rb");

    if (binario == NULL)
        return;
    // verifica qual o RRN desejado pelo usuario
    scanf("%d", &RRN);

    // sabe-se que cada registro tem 1 + 4 + 4 + 4 + 4 + 1 (char, int, int, int, int, char) bytes = 18 bytes

    // comeco a procurar o RRN a partir do fim do cabecalho
    fseek(binario, 17 + RRN * 18, SEEK_SET);

    Registro Reg;

    // vai verificar se a leitura ocorreu de fato e se o registro esta removido ou nao
    if (!Leitura_Registro(binario, &Reg) || Reg.removido == '1')
    {
        printf("Registro inexistente.\n");
    }
    // ira printar as informacoes necessarias com o tratamento de NULO e de -1
    else
    {
        print_registro(&Reg);
    }

    fclose(binario);
}

// aqui se encerra a funcionalidade 4
//_______________________________

// Funcionalidade 5

void remocao_logica()
{
    // inicio as variaveis para pegar nome do arquivo, a quantidade de criterios
    // a serem utilizados e o numero de repeticoes da busca
    char arquivo_binario[30];
    int repeticoes;
    int qtd_criterios;

    scanf("%s %d", arquivo_binario, &repeticoes);

    FILE *binario = verificar_arquivo(arquivo_binario, "rb+");

    // retorno caso o arquivo tenha uma falha no seu processamento
    if (binario == NULL)
    {
        return;
    }

    RegCabecalho Cabecalho = Leitura_Cabecalho(binario);

    // status do cabecalho e atualizado ja que ele esta sendo alterado
    // e pode estar temporariamente inconsistente
    Cabecalho.status = '0';
    fseek(binario, 0, SEEK_SET);
    fwrite(&Cabecalho.status, sizeof(char), 1, binario);
    fflush(binario); // segue rigorosamente o proposito de status, ja que envia
    // imediatamente para o arquivo algo que pode estar temporariamente guardado no buffer de escrita

    // o loop usado na busca e iniciado
    for (int busca_atual = 0; busca_atual < repeticoes; busca_atual++)
    {
        scanf("%d", &qtd_criterios);
        Criterios C = ler_criterios(qtd_criterios);

        // cursor e colocado no comeco dos registros
        fseek(binario, 17, SEEK_SET);
        Registro Reg;
        int RRN_registro = 0;

        // loop que vai fazer a leitura do registro e verificar o encontro dos criterios desejados
        while (Leitura_Registro(binario, &Reg))
        {

            // se o registro já estiver removido, a iteração atual é encerrada
            //  mas o RRN e incrementado mesmo assim
            if (Reg.removido == '1')
            {
                RRN_registro++;
                continue;
            }

            // o encontro dos parametros buscados e verificado
            if (verificar_encontro(&C, &Reg))
            {
                // o registro e removido e o contador do numero de registros removidos e incrementado
                remove_registro(&Reg, &Cabecalho, RRN_registro);
                Cabecalho.nroRegRem++;

                // o cursor volta ao registro que deve ser removido para que a escrita seja feita
                fseek(binario, 17 + RRN_registro * 18, SEEK_SET);
                escreve_registro(binario, &Reg);

                // cursor retorna ao fim do registro que foi removido
                // tambem funciona como sincronizacao entre o fread e o fwrite
                fseek(binario, 17 + (RRN_registro + 1) * 18, SEEK_SET);
            }
            // o RRN e incrementado
            RRN_registro++;
        }
    }

    // cabecalho e atualizado
    fseek(binario, 0, SEEK_SET);
    escreve_cabecalho(binario, &Cabecalho);

    // valor do status e atulizado e escrito por ultimo para garantir que tudo
    // terminou corretamente, ou seja, o arquivo esta consistente
    Cabecalho.status = '1';
    fseek(binario, 0, SEEK_SET);
    fwrite(&Cabecalho.status, sizeof(char), 1, binario);
    fclose(binario);
    // funcao binario na tela e utilizada para printar o arquivo atualizado
    BinarioNaTela(arquivo_binario);
}

// aqui se encerra a funcionalidade 5
//_______________________________

// Funcionalidade 6
void insercao()

{
    // declara a variavel para armazenar o nome do arquivo e ler
    char arquivo_binario[50];
    scanf("%s", arquivo_binario);

    Registro Reg;

    // abre o arquivo para leitura e escrita e verifica se está corrompido
    FILE *binario = verificar_arquivo(arquivo_binario, "rb+");
    if (binario == NULL) // Se encontrar algum erro, ele retorna
    {
        return;
    }
    RegCabecalho cabecalho = Leitura_Cabecalho(binario); // definicao da struct e leitura do arquivo binario

    cabecalho.status = '0'; // como vamos escrever no arquivo, o status deve estar inconsistente
    fseek(binario, 0, SEEK_SET);
    fwrite(&cabecalho.status, sizeof(char), 1, binario);

    // le do teclado os valores dos campos a serem inseridos

    // cria strings temporarias para utilizar a funcao scanQuoteString para trabalhar com valores nulos e caracteres entre aspas
    // dos campos de velocidade e unidade de medida
    char temp_velocidade[20];
    char temp_unidade_medida[20];
    int n;
    scanf("%d", &n); // le o numero de registros a serem inseridos

    for (int i = 0; i < n; i++)
    { // le os valores passados pelo teclado para os campos do registro
        scanf("%d", &Reg.idPoPs);
        scanf("%d", &Reg.idPoPsConectado);
        scanf("%19s", temp_velocidade);
        ScanQuoteString(temp_unidade_medida);

        // faz a comparação das strings temporarias com o valor nulo, se for verdadeiro atribui -1 a velocidade e $ a unidade
        // de medida, se for falso, ele atribui o valor lido do teclado para velocidade e o caractere lido sem aspas
        if (strcmp(temp_velocidade, "") == 0 || strcmp(temp_velocidade, "NULO") == 0)
        {
            Reg.velocidade = -1; // atribui -1 se o campo for nulo
        }
        else
        {
            Reg.velocidade = atoi(temp_velocidade);
        }
        if (strcmp(temp_unidade_medida, "") == 0 || strcmp(temp_unidade_medida, "NULO") == 0)
        {
            Reg.unidade_medida = '$'; // atribui '$' se o campo for nulo
        }
        else
        {
            Reg.unidade_medida = temp_unidade_medida[0];
        }
        if (cabecalho.topo_pilha == -1) // verifica se há registros removidos pelo topo da pilha
        {

            fseek(binario, 17 + cabecalho.proxRRN * 18, SEEK_SET);
            Reg.removido = '0';
            Reg.encadeamento = -1;
            escreve_registro(binario, &Reg);
            cabecalho.proxRRN++;

            // Atualiza os valores do cabecalho que foram alterados dentro da condicional
        }
        else
        {
            int proximo_registro;

            fseek(binario, 17 + cabecalho.topo_pilha * 18 + 1, SEEK_SET);
            fread(&proximo_registro, sizeof(int), 1, binario); // verifica qual o proximo registro
            int temp = cabecalho.topo_pilha;                   // guarda o valor do topo da pilha em uma variavel temporaria
            cabecalho.topo_pilha = proximo_registro;           // removido e atualiza o topo da pilha para esse valor
            Reg.encadeamento = -1;                             // atualiza o encadeamento para -1 indicando que o registro não está mais removido

            fseek(binario, 17 + temp * 18, SEEK_SET);
            Reg.removido = '0'; // atribui o valor 0 ao novo registro inserido e escreve no arquivo
            escreve_registro(binario, &Reg);
            cabecalho.nroRegRem--; // atualiza o numero de registros removidos no cabecalho
            cabecalho.nroPares++;  // atualiza o numero de pares no cabecalho
        }
    }
    // Atualiza os valores do cabecalho que foram alterados
    fseek(binario, 0, SEEK_SET);
    escreve_cabecalho(binario, &cabecalho);

    // status e atualizado e escrito por ultimo para manter a consistencia
    cabecalho.status = '1';
    fseek(binario, 0, SEEK_SET);
    fwrite(&cabecalho.status, sizeof(char), 1, binario);

    fclose(binario);
    BinarioNaTela(arquivo_binario); // chama a funcao para imprimir o arquivo binario na tela
}

// aqui se encerra a funcionalidade 6
//_______________________________

// Funcionalidade 7

void atualizacao_registros()
{
    // crio as variaveis do nome do arquivo e do numero de repeticoes
    char arquivo_binario[50];
    int repeticoes;

    // le o nome do arquivo e o numero de repeticoes
    scanf("%s %d", arquivo_binario, &repeticoes);

    // abre o arquivo para leitura e escrita e verifica se esta consistente
    FILE *binario =
        verificar_arquivo(arquivo_binario, "rb+");

    if (binario == NULL)
    {
        return;
    }

    // le o cabecalho do arquivo
    RegCabecalho Cabecalho =
        Leitura_Cabecalho(binario);

    // atualiza o status, pois o arquivo sera alterado
    // e pode ficar temporariamente inconsistente
    Cabecalho.status = '0';

    fseek(binario, 0, SEEK_SET);
    fwrite(
        &Cabecalho.status,
        sizeof(char),
        1,
        binario);

    // garante que o status 0 seja enviado ao arquivo
    // antes do inicio das atualizacoes
    fflush(binario);

    // inicia o laco externo das n buscas e atualizacoes
    for (
        int busca_atual = 0;
        busca_atual < repeticoes;
        busca_atual++)
    {
        // le quantos criterios serao utilizados na busca
        int qtd_criterios;
        scanf("%d", &qtd_criterios);

        // le e guarda os criterios da busca
        Criterios C = ler_criterios(qtd_criterios);

        // le quantos campos serao atualizados
        int qtd_atualizacoes;
        scanf("%d", &qtd_atualizacoes);

        // le e guarda os novos valores
        Criterios A = ler_criterios(qtd_atualizacoes);

        // pula para o byteoffset 17 do arquivo,
        // pois e onde comecam os registros
        fseek(binario, 17, SEEK_SET);

        Registro Reg;

        // percorre todos os registros do arquivo
        while (Leitura_Registro(binario, &Reg))
        {
            // se o registro estiver removido,
            // ele e ignorado
            if (Reg.removido == '1')
            {
                continue;
            }

            // verifica se o registro atual atende
            // a todos os criterios da busca
            if (verificar_encontro(&C, &Reg))
            {
                // atualiza apenas os campos informados
                if (A.idPoPs != -2)
                {
                    Reg.idPoPs = A.idPoPs;
                }

                if (A.idPoPsConectado != -2)
                {
                    Reg.idPoPsConectado = A.idPoPsConectado;
                }

                if (A.velocidade != -2)
                {
                    Reg.velocidade = A.velocidade;
                }

                if (A.unidadeMedida != -2)
                {
                    Reg.unidade_medida = A.unidadeMedida;
                }

                // como o registro foi lido por completo,
                // o cursor retorna 18 bytes para o inicio dele
                fseek(binario, -18, SEEK_CUR);

                // escreve campo a campo o registro atualizado
                escreve_registro(binario, &Reg);

                // sincroniza a mudanca de escrita para leitura
                // e mantem o cursor no inicio do proximo registro
                fseek(binario, 0, SEEK_CUR);
            }
        }
    }

    // atualiza o status para 1 depois que todas
    // as atualizacoes foram realizadas
    Cabecalho.status = '1';

    // escreve o status por ultimo, indicando
    // que o arquivo esta consistente
    fseek(binario, 0, SEEK_SET);
    fwrite(&Cabecalho.status, sizeof(char), 1, binario);
    fclose(binario);

    // mostra o arquivo binario atualizado
    BinarioNaTela(arquivo_binario);
}

// aqui se encerra a funcionalidade 7
//_______________________________
